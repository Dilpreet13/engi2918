<?php ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $title." - ENGI2918" ?></title>
    <script type="text/javascript" href="<?php echo base_url("assets/js/jquery-3.2.1.min.js") ?>"></script>
    <script type="text/javascript" href="<?php echo base_url("assets/js/popper.js") ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/bootstrap.css") ?>"></link>
    <script type="text/javascript" href="<?php echo base_url("assets/js/bootstrap.js") ?>"></script>
</head>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: Ian Cuninghame
 * Date: 2018-03-19
 * Time: 5:37 PM
 */
?>
<div class="container">
    <footer class="footer">
        <p>&copy; Lakehead University 2018</p>
    </footer>
</div>
</html>
